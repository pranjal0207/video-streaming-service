const { DynamoDBClient, UpdateItemCommand } = require("@aws-sdk/client-dynamodb");

// Create a DynamoDB client object
const ddbClient = new DynamoDBClient({ region: "us-east-1" }); // Ensure you use the correct region

exports.handler = async (event) => {
  const key = event.s3.object.Key

  const videoData = key.split('/')

  const response = {
    statusCode: 200,
    // body: JSON.stringify('Hello from Lambda!'),
    body: {
      message: videoData
    }
  };
  return response;

  // const params = {
  //   TableName: "Users",
  //   Key: {
  //     "userId": { S: userId }
  //   },
  //   UpdateExpression: "set email = :e",
  //   ExpressionAttributeValues: {
  //     ":e": { S: newEmail }
  //   },
  //   ReturnValues: "UPDATED_NEW"
  // };

  // try {
  //   const data = await ddbClient.send(new UpdateItemCommand(params));
  //   console.log("Success - item updated", data);
  //   return { statusCode: 200, body: JSON.stringify(data) };
  // } catch (err) {
  //   console.error("Error", err);
  //   return { statusCode: 500, body: JSON.stringify(err) };
  // }
};